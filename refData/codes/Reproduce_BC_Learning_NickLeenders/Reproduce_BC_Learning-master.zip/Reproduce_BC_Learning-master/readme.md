See notebook for code explanation
