
## TODO

## After report

Dissemination

- Image of overall project/system
- Project image, title page
- Publish on Arxiv? cs.LG cs.SD eess.AS stat.ML
- Write a blogpost

Related

- STM32AI: Report melspec preprocessing bug
https://community.st.com/s/topic/0TO0X0000003iUqWAI/stm32-machine-learning-ai

Experiment

- Test 16kHz with 30 mels
- Use multi-instance learning. Get bigger batches and improve GPU utilization
- Do hyperparameter optimization per model
- Double-check reproduction of SB-CNN results
- Improve Data Augmentation

