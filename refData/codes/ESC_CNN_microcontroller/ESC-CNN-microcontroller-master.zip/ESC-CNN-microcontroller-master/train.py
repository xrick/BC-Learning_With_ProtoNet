
from microesc import train
train.main()
